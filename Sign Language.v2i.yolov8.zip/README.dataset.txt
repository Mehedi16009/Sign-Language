# Sign Language > 2024-08-11 11:28am
https://universe.roboflow.com/sign-language-mehedi/sign-language-kqyow

Provided by a Roboflow user
License: CC BY 4.0

